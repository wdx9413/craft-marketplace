import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { tmpdir } from "node:os";
import { join, resolve, sep } from "node:path";
import { sourceProvenance } from "./source-provenance.mjs";
import { COMPONENT_OWNED_PATHS, isGeneratedCacheEntry, MARKETPLACE_OWNED_PATHS } from "./component-contract.mjs";

/**
 * Syncs this marketplace's plugin payloads from the craft source repository.
 *
 * Why a script and not a copy command: the marketplace is a **published** surface, and it had
 * drifted from the source that produces it in two ways that nothing was checking.
 *
 *  1. **The payloads were stale.** Every `dist/plugin/craft-mcp.cjs` here differed from the one a
 *     fresh build produces. A Host installing from the marketplace therefore ran code that the
 *     source no longer contained, and no diff in either repository said so.
 *  2. **A component had been renamed in the source and not here.** `craft-workflow-evolution`
 *     became `craft-experience` in `craft/plugins/`, so the marketplace was publishing a name the
 *     source had stopped using — including in `release.json`, whose own note says a stale field
 *     "is exactly the kind of silent disagreement this file exists to prevent".
 *
 * ### The marketplace owns one thing the source does not
 *
 * Component manifests are source-owned. The marketplace copies both Codex and
 * Claude manifests with the payload so the two Hosts cannot silently publish
 * different versions or product arguments.
 *
 * ### What it refuses to do
 *
 *  - It fails if a component is missing on either side, rather than skipping it — a plugin that
 *    silently stops being published is worse than a failing sync.
 *  - It fails if a copied file lands empty or gains U+FFFD, because both have happened here before
 *    through the wrong `Set-Content`/`-Encoding` and a 2 MB bundle of mojibake is not obvious.
 *  - It reports every changed file, so the commit that follows is reviewable.
 */
const args = process.argv.slice(2);
const apply = args.includes("--apply");
const unsupported = args.filter((arg) => arg.startsWith("--") && arg !== "--apply" && arg !== "--check");
if (unsupported.length) throw new Error(`unsupported argument(s): ${unsupported.join(", ")}`);
const sourceArgument = args.find((arg) => !arg.startsWith("--"));
// A marketplace checkout must not depend on a sibling craft repository. The
// publishing job passes the packed plugins directory explicitly, or an operator
// points at a verified source archive.
if (!sourceArgument) throw new Error("Craft plugins directory is required; pass it explicitly instead of relying on a sibling ../craft checkout");
const sourceRoot = resolve(sourceArgument);
const marketplaceRoot = process.cwd();
const sourceRepo = resolve(sourceRoot, "..");
const contractPath = join(sourceRepo, "distribution-contract.json");
if (!existsSync(contractPath)) throw new Error(`Craft distribution contract is missing: ${contractPath}`);
const contract = JSON.parse(readFileSync(contractPath, "utf8"));
if (!/^\d+\.\d+\.\d+$/u.test(String(contract.version)) || !Array.isArray(contract.products)) throw new Error("Craft distribution contract is invalid");

/**
 * Craft source keeps its complete internal/plugin catalog. This marketplace
 * publishes only the explicit external distribution contract.
 */
const EXPORTED_COMPONENTS = contract.products.map((product) => String(product?.name)).sort();
if (new Set(EXPORTED_COMPONENTS).size !== EXPORTED_COMPONENTS.length || EXPORTED_COMPONENTS.length === 0) throw new Error("External marketplace contract must contain unique products");
/**
 * Marketplace directories that no longer correspond to a component in the source, and where their
 * marketplace-owned files belong now.
 *
 * An earlier version of this script mapped *source* names to new ones, which assumed the source still
 * used the old name — it does not, so nothing fired and the stale directory survived. A later version
 * simply removed the obsolete directory, which **deleted that component's Claude manifest** and
 * dropped it out of `claude_components` — the exact failure this file's own comment warned about.
 * So the mapping's job is to carry marketplace-owned files across the rename before removing anything.
 */
const RENAMED = { "craft-workflow-evolution": "craft-experience" };

const availableSourceComponents = readdirSync(sourceRoot, { withFileTypes: true })
  .filter((entry) => entry.isDirectory())
  .map((entry) => entry.name)
  .sort();
const missingExports = EXPORTED_COMPONENTS.filter((name) => !availableSourceComponents.includes(name));
if (missingExports.length) throw new Error(`Craft source is missing required exported component(s): ${missingExports.join(", ")}`);
const sourceComponents = [...EXPORTED_COMPONENTS].sort();
function marketplaceEntries() {
  return contract.products.map((product) => ({
    name: String(product.name),
    source: { source: "local", path: `./plugins/${String(product.name)}` },
    policy: { installation: "AVAILABLE", authentication: "ON_INSTALL" },
    category: String(product.category),
  }));
}

function claudeEntries() {
  return contract.products.map((product) => {
    const manifest = JSON.parse(readFileSync(join(sourceRoot, String(product.name), ".claude-plugin", "plugin.json"), "utf8"));
    return { name: String(product.name), description: String(manifest.description), source: `./plugins/${String(product.name)}`, category: String(product.category) === "Developer Tools" ? "development" : "productivity" };
  });
}

/**
 * Files the source owns, relative to a component directory. Everything else is left alone.
 *
 * `README.md` is here because it is a payload file the source generates, and leaving it out is how
 * this repository kept a README naming a component the source had already renamed: the file was
 * never refreshed, so no amount of syncing would have corrected it. Only the full `craft` component
 * has one, and the loop skips what is absent.
 */
// Skill files are maintained in the Marketplace: Craft source excludes them from Git.
const OWNED = COMPONENT_OWNED_PATHS;
const generatedCache = isGeneratedCacheEntry;
/**
 * Payload files this marketplace ships that the Craft source does not generate.
 *
 * `craft-datasec` publishes an OpenCode adapter (`dist/opencode.mjs`) built by
 * the Datasec build, not copied from `plugins/`. Replacing the whole `dist`
 * directory would silently drop it, so it is preserved across a sync and
 * accepted by verification in addition to the source tree.
 */
const marketplaceOwned = (component) => MARKETPLACE_OWNED_PATHS[component] ?? [];
const extraOwnedNames = (owned) => marketplaceOwned(owned.component)
  .filter((path) => joinedMatches(path, owned.path));

/** Compare a POSIX-style relative payload path against a path built with `join`. */
function joinedMatches(payloadPath, ownedPath) {
  return payloadPath.split("/").join(sep) === ownedPath || payloadPath.startsWith(`${ownedPath.split(sep).join("/")}/`);
}

const sourceRevision = () => sourceProvenance(sourceRepo, contract.version, process.env.CRAFT_SOURCE_COMMIT);
const componentSourceCommits = () => {
  const archivedCommit = process.env.CRAFT_SOURCE_COMMIT;
  if (archivedCommit !== undefined && !/^[a-f0-9]{40}$/u.test(archivedCommit)) throw new Error("CRAFT_SOURCE_COMMIT must be a full Git SHA");
  return Object.fromEntries(sourceComponents.map((component) => {
    const commit = archivedCommit ?? execFileSync("git", ["-C", sourceRepo, "log", "-1", "--format=%H", "--", `plugins/${component}`], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim();
    if (!/^[a-f0-9]{40}$/u.test(commit)) throw new Error(`source commit is unavailable for plugins/${component}`);
    return [component, commit];
  }));
};
const readmeVersionLine = () => readFileSync(join(marketplaceRoot, "README.md"), "utf8").split(/\r?\n/u).find((line) => /^- Craft version/u.test(line));
const updateReadmeVersion = () => {
  const path = join(marketplaceRoot, "README.md");
  const readme = readFileSync(path, "utf8");
  const lines = readme.split(/\r?\n/u);
  const index = lines.findIndex((line) => /^- Craft version/u.test(line));
  if (index < 0) throw new Error("README.md is missing its Craft version line");
  lines[index] = `- Craft version：\`${contract.version}\``;
  writeFileSync(path, lines.join(readme.includes("\r\n") ? "\r\n" : "\n"), "utf8");
};

const sameFile = (left, right) => existsSync(right)
  && statSync(left).isFile() && statSync(right).isFile()
  && Buffer.compare(readFileSync(left), readFileSync(right)) === 0;

const sameTree = (left, right) => {
  if (!existsSync(right)) return false;
  const leftInfo = statSync(left); const rightInfo = statSync(right);
  if (leftInfo.isFile() || rightInfo.isFile()) return leftInfo.isFile() && rightInfo.isFile() && sameFile(left, right);
  const leftEntries = readdirSync(left).filter((entry) => !generatedCache(entry)).sort();
  const rightEntries = readdirSync(right).filter((entry) => !generatedCache(entry)).sort();
  return leftEntries.length === rightEntries.length
    && leftEntries.every((entry, index) => entry === rightEntries[index] && sameTree(join(left, entry), join(right, entry)));
};

/**
 * Compare one OWNED path while accepting marketplace-owned extras beneath it.
 *
 * A source-owned file is compared byte-for-byte with no exceptions. A source-owned
 * directory may contain marketplace-owned payloads (for example Datasec's OpenCode
 * bundle under `dist/`); those names are overlaid onto a throwaway copy of the
 * source before the same strict comparison runs.
 */
const sameOwnedTree = (left, right, extras = [], owned = "") => {
  if (!existsSync(left)) return !existsSync(right) || extras.every((path) => !existsSync(right));
  if (!existsSync(right)) return false;
  if (sameTree(left, right)) return true;
  // Only widen the comparison for a real, present marketplace-owned payload.
  if (extras.length === 0) return false;
  const payloads = extras.flatMap((relative) => {
    const parts = relative.split("/"), index = parts.indexOf(owned.split(sep).join("/"));
    return index < 0 ? [] : [{ relative, name: parts.slice(index + 1).join("/") }];
  });
  if (payloads.length === 0) return false;
  const payloadNames = payloads.map((payload) => payload.name);
  const parent = mkdtempSync(join(tmpdir(), "craft-marketplace-verify-"));
  const scratch = join(parent, "tree");
  try {
    cpSync(left, scratch, { recursive: true, force: true, filter: (path) => !path.split(sep).some(generatedCache) });
    for (const payload of payloads) {
      const source = join(right, payload.name);
      if (!existsSync(source)) return false;
      const target = join(scratch, payload.name);
      mkdirSync(resolve(target, ".."), { recursive: true });
      cpSync(source, target, { recursive: true, force: true });
    }
    const fromScratch = relativeNamesOf(scratch).filter((name) => !payloadNames.includes(name));
    const fromMarket = relativeNamesOf(right).filter((name) => !payloadNames.includes(name));
    return JSON.stringify(fromScratch) === JSON.stringify(fromMarket)
      && fromScratch.every((name) => sameFile(join(scratch, name), join(right, name)));
  } finally { rmSync(parent, { recursive: true, force: true }); }
};

function relativeNamesOf(root) {
  if (statSync(root).isFile()) return [""];
  return readdirSync(root).filter((entry) => !generatedCache(entry)).flatMap((entry) => {
    const child = join(root, entry);
    return statSync(child).isDirectory() ? relativeNamesOf(child).map((name) => (name ? join(entry, name) : entry)) : [entry];
  }).sort();
}

const verifyMarketplace = () => {
  const drift = [];
  const manifestDrift = [];
  for (const component of sourceComponents) {
    const from = join(sourceRoot, component); const to = join(marketplaceRoot, "plugins", component);
    if (existsSync(join(to, "dsh"))) throw new Error(`plugins/${component}/dsh is a retired DSH payload`);
    // Manifest drift is checked before payload drift so a stale manifest names
    // the file a release must fix, even when a payload is also missing.
    const claude = join(to, ".claude-plugin", "plugin.json");
    if (!existsSync(claude)) throw new Error(`missing Claude manifest for ${component}`);
    const manifest = JSON.parse(readFileSync(claude, "utf8"));
    const productVersion = contract.products.find(product => product.name === component).version ?? contract.version;
    if (manifest.name !== component || manifest.version !== productVersion) manifestDrift.push(`Claude manifest drift for ${component}`);
    for (const owned of OWNED) {
      const source = join(from, owned);
      const target = join(to, owned);
      if (!sameOwnedTree(source, target, extraOwnedNames({ component, path: owned }), owned)) drift.push(`marketplace payload drift: plugins/${component}/${owned}`);
    }
  }
  if (drift.length) throw new Error(drift[0]);
  if (manifestDrift.length) throw new Error(manifestDrift[0]);
  const published = readdirSync(join(marketplaceRoot, "plugins"), { withFileTypes: true })
    .filter((entry) => entry.isDirectory()).map((entry) => entry.name).sort();
  if (JSON.stringify(published) !== JSON.stringify(sourceComponents)) throw new Error("marketplace product set differs from distribution contract");
  const release = JSON.parse(readFileSync(join(marketplaceRoot, "release.json"), "utf8"));
  const revision = sourceRevision();
  if (release.version !== contract.version
    || JSON.stringify(release.components) !== JSON.stringify(sourceComponents)
    || JSON.stringify(release.claude_components) !== JSON.stringify(sourceComponents)
    || release.source_commit !== revision.source_commit
    || release.source_state !== revision.source_state
    || release.source_tree_digest !== revision.source_tree_digest
    || release.source_note !== revision.source_note) throw new Error("release.json differs from the source distribution contract");
  if (JSON.stringify(release.component_source_commits) !== JSON.stringify(componentSourceCommits())) throw new Error("release.json component source commit is stale");
  if (readmeVersionLine() !== `- Craft version：\`${contract.version}\``) throw new Error("README.md Craft version differs from the source distribution contract");
  for (const manifestPath of [".agents/plugins/marketplace.json"]) {
    const manifest = JSON.parse(readFileSync(join(marketplaceRoot, manifestPath), "utf8"));
    if (manifest.version !== contract.version || JSON.stringify(manifest.plugins) !== JSON.stringify(marketplaceEntries())) throw new Error(`${manifestPath} differs from the source distribution contract`);
  }
  const claude = JSON.parse(readFileSync(join(marketplaceRoot, ".claude-plugin", "marketplace.json"), "utf8"));
  if (claude.version !== contract.version || JSON.stringify(claude.plugins) !== JSON.stringify(claudeEntries())) throw new Error("Claude marketplace differs from the source distribution contract");
};

if (!apply) {
  verifyMarketplace();
  console.log(`Verified ${sourceComponents.length} component(s) against ${sourceRoot}; no files changed. Re-run with --apply to synchronize.`);
  process.exit(0);
}

const report = [];
for (const component of sourceComponents) {
  const dshPayload = join(marketplaceRoot, "plugins", component, "dsh");
  if (!existsSync(dshPayload)) continue;
  rmSync(dshPayload, { recursive: true, force: true });
  report.push(`removed  plugins/${component}/dsh (DSH payloads are no longer released)`);
}
for (const [oldName, newName] of Object.entries(RENAMED)) {
  const stale = join(marketplaceRoot, "plugins", oldName);
  if (!existsSync(stale)) continue;
  const claude = join(stale, ".claude-plugin");
  if (existsSync(claude)) {
    const target = join(marketplaceRoot, "plugins", newName, ".claude-plugin");
    mkdirSync(target, { recursive: true });
    cpSync(claude, target, { recursive: true, force: true });
    report.push(`carried  plugins/${oldName}/.claude-plugin -> plugins/${newName}/.claude-plugin`);
  }
  rmSync(stale, { recursive: true, force: true });
  report.push(`removed  plugins/${oldName} (renamed to ${newName} in the source)`);
}

const sync = (component) => {
  const from = join(sourceRoot, component);
  const to = join(marketplaceRoot, "plugins", component);
  for (const owned of OWNED) {
    const source = join(from, owned);
    const target = join(to, owned);
    if (!existsSync(source)) {
      if (existsSync(target)) {
        rmSync(target, { recursive: true, force: true });
        report.push(`removed  plugins/${component}/${owned} (absent from source)`);
      }
      continue;
    }
    mkdirSync(to, { recursive: true });
    const staged = [];
    if (statSync(source).isDirectory()) {
      for (const relative of extraOwnedNames({ component, path: owned })) {
        const payload = join(to, relative);
        const suffix = relative.split("/").slice(owned.split(sep).length).join("/");
        if (!existsSync(payload)) continue;
        const temporary = join(mkdtempSync(join(tmpdir(), "craft-marketplace-own-")), suffix.replaceAll("/", "_"));
        mkdirSync(resolve(temporary, ".."), { recursive: true });
        cpSync(payload, temporary, { force: true });
        staged.push({ temporary, payload });
      }
      rmSync(target, { recursive: true, force: true });
    }
    cpSync(source, target, { recursive: true, force: true, filter: (path) => !path.split(sep).some(generatedCache) });
    for (const item of staged) {
      mkdirSync(resolve(item.payload, ".."), { recursive: true });
      cpSync(item.temporary, item.payload, { force: true });
      rmSync(resolve(item.temporary, ".."), { recursive: true, force: true });
      report.push(`kept     plugins/${component}/${item.payload.slice(join(marketplaceRoot, "plugins", component).length + 1).split(sep).join("/")} (marketplace-owned)`);
    }
    report.push(`synced   plugins/${component}/${owned}`);
  }
};

for (const component of sourceComponents) sync(component);

for (const manifestPath of [".agents/plugins/marketplace.json"]) {
  const manifestPathResolved = join(marketplaceRoot, manifestPath);
  const manifest = JSON.parse(readFileSync(manifestPathResolved, "utf8"));
  manifest.version = contract.version;
  manifest.plugins = marketplaceEntries();
  writeFileSync(manifestPathResolved, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
  report.push(`updated  ${manifestPath} products -> ${sourceComponents.join(", ")}`);
}
const claudeMarketplacePath = join(marketplaceRoot, ".claude-plugin", "marketplace.json");
const claudeMarketplace = JSON.parse(readFileSync(claudeMarketplacePath, "utf8"));
claudeMarketplace.version = contract.version;
claudeMarketplace.plugins = claudeEntries();
writeFileSync(claudeMarketplacePath, `${JSON.stringify(claudeMarketplace, null, 2)}\n`, "utf8");
report.push(`updated  .claude-plugin/marketplace.json products -> ${sourceComponents.join(", ")}`);
updateReadmeVersion();
report.push(`updated  README.md Craft version -> ${contract.version}`);

// This distribution must contain exactly the explicitly exported components.  The source can
// retain additional private/internal products without leaking them into either marketplace.
const published = readdirSync(join(marketplaceRoot, "plugins"), { withFileTypes: true })
  .filter((entry) => entry.isDirectory())
  .map((entry) => entry.name)
  .sort();
const expected = [...sourceComponents].sort();
const extra = published.filter((name) => !expected.includes(name));
for (const name of extra) {
  rmSync(join(marketplaceRoot, "plugins", name), { recursive: true, force: true });
  report.push(`removed  plugins/${name} (not an external marketplace product)`);
}

// Every copied file must be non-empty and free of replacement characters.
let checked = 0;
for (const component of expected) {
  const walk = (dir) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const full = join(dir, entry.name);
      if (entry.isDirectory()) { walk(full); continue; }
      if (statSync(full).size === 0) throw new Error(`${full} is empty`);
      checked += 1;
      if (!/\.(?:cjs|js|json|md|svg)$/u.test(entry.name)) continue;
      if (readFileSync(full, "utf8").includes("\uFFFD")) throw new Error(`${full} contains U+FFFD`);
    }
  };
  walk(join(marketplaceRoot, "plugins", component));
}

// `release.json` names the components, so a rename that stops here would leave the manifest
// describing a component set that no longer exists.
const releasePath = join(marketplaceRoot, "release.json");
const release = JSON.parse(readFileSync(releasePath, "utf8"));
release.components = expected;
release.claude_components = expected.filter((name) => existsSync(join(marketplaceRoot, "plugins", name, ".claude-plugin")));
release.version = contract.version;
release.component_source_commits = componentSourceCommits();
report.push(`updated  release.json component source commits -> ${expected.map((name) => `${name}@${release.component_source_commits[name].slice(0, 12)}`).join(", ")}`);

/**
 * The checkout these payloads were synchronized from (not a build attestation).
 *
 * This field was maintained by hand, and it went stale the moment the release became a merge:
 * `plugins/` here held a fresh build of the merge commit while `source_commit` still named the
 * branch tip the payloads had been built from before it. A note in this file calls a stale field
 * "exactly the kind of silent disagreement this file exists to prevent", so the revision is read
 * from Git at sync time. `source_commit` is HEAD; `source_tree_digest` binds the
 * Git-visible working-tree bytes, including untracked source. Ignored build outputs
 * are checked byte-for-byte above, but this does not prove when/how they were built.
 */
try {
  const revision = sourceRevision();
  release.source_commit = revision.source_commit;
  release.source_state = revision.source_state;
  release.source_tree_digest = revision.source_tree_digest;
  release.source_note = revision.source_note;
  report.push(`updated  release.json source_commit -> ${revision.source_commit.slice(0, 12)} (${release.source_state})`);
} catch (error) {
  const message = error instanceof Error ? error.message.split("\n")[0] : String(error);
  report.push(`kept     release.json source_commit (git unavailable: ${message})`);
}

writeFileSync(releasePath, `${JSON.stringify(release, null, 2)}\n`, "utf8");
report.push(`updated  release.json components -> ${expected.join(", ")}`);
verifyMarketplace();

for (const line of report) console.log(`OK   ${line}`);
console.log(`Synced ${expected.length} component(s) from ${sourceRoot}; ${checked} file(s) checked for emptiness and U+FFFD.`);
